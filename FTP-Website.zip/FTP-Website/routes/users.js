var express = require('express');
var router = express.Router();
/*var multer = require('multer');
var upload = multer({dest: './uploads'});*/
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var fs = require('fs');
var crypto = require('crypto');
let cookieParser = require('cookie-parser');
router.use(cookieParser());



//Mongoose
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/FTP-Website');
var db = mongoose.connection;



//Encryption
function encryptionData()
{
  var fileData = fs.readFileSync('logincontrol.txt').toString();
  var i;
  var key = '';
  var iv = '';
  for(i = 0; i < (fileData.length - 18); i++)
  {
    key += fileData[i];
  }
  for(i = (fileData.length - 16); i < fileData.length; i++)
  {
    iv += fileData[i];
  }
  return [key, iv]
}

const eData = encryptionData();

const ENC_KEY = eData[0]; // set random encryption key
const IV = eData[1]; // set random initialisation vector

function encrypt(val)
{
  let cipher = crypto.createCipheriv('aes-256-cbc', ENC_KEY, IV);
  let encrypted = cipher.update(val, 'utf8', 'base64');
  encrypted += cipher.final('base64');
  return encrypted;
}

function decrypt(encrypted)
{
  let decipher = crypto.createDecipheriv('aes-256-cbc', ENC_KEY, IV);
  let decrypted = decipher.update(encrypted, 'base64', 'utf8');
  return (decrypted + decipher.final('utf8'));
}



/* GET users listing. */
router.get('/', function(req, res, next) {
  res.location('/users/login');
  res.redirect('/users/login');
  //res.send('respond with a resource');
});



router.get('/register', function(req, res, next) {
  if(req.cookies.userData != undefined)
  {
    if(req.cookies.userData.loggedin == true)//===========================================================
    {
      db.collection('users').findOne({username: req.cookies.userData.username}, function(err, user) {
        if(user.password == req.cookies.userData.password)
        {
          res.location('/');
          res.redirect('/');
        }
        else
        {
          res.clearCookie('userData');
          req.flash('info', '');
          res.render('register', {messages: req.flash('info')});
          res.render('register');
        }
      });
    }
  }
  else
  {
    res.clearCookie('userData');
    req.flash('info', '');
    res.render('register', {messages: req.flash('info')});
    res.render('register');
  }
});



router.get('/login', function(req, res, next) {
  if(req.cookies.userData != undefined)
  {
    if(req.cookies.userData.loggedin == true)
    {
      db.collection('users').findOne({username: req.cookies.userData.username}, function(err, user) {
        if(user.password == req.cookies.userData.password)
        {
          res.location('/');
          res.redirect('/');
        }
        else
        {
          res.clearCookie('userData');
          req.flash('info', '');
          res.render('login', {messages: req.flash('info')});
          res.render('login');
        }
      });
    }
  }
  else
  {
    res.clearCookie('userData');
    req.flash('info', '');
    res.render('login', {messages: req.flash('info')});
    res.render('login');
  }
});



router.get('/update', function(req, res, next) {
  if(req.cookies.userData != undefined)
  {
    if(req.cookies.userData.loggedin == true)
    {
      db.collection('users').findOne({username: req.cookies.userData.username}, function(err, user) {
        if(user.password == req.cookies.userData.password)
        {
          req.flash('info', '');
          res.render('update', {messages: req.flash('info')});
          res.render('update');
        }
        else
        {
          req.flash('info', "You are not logged in and therefore cannot go to the server page");
          res.render('login', {messages: req.flash('info')});
          res.location('/users/login');
          res.redirect('/users/login');
        }
      });
    }
  }
  else
  {
    req.flash('info', "You are not logged in and therefore cannot go to the update page");
    res.render('login', {messages: req.flash('info')});
    res.location('/users/login');
    res.redirect('/users/login');
  }
});



function changeUsernameAccess(oldUsername, newUsername, req, res, next)
{
  db.collection('files').find().toArray(function(err, files){
    if (err) throw err;
    var i;
    var j;
    for (i = 0; i < files.length; i++)
    {
      for (j = 0; j < files[i].access.length; j++)
      {
        if(files[i].access[j][0] == oldUsername)
        {
          files[i].access[j][0] = newUsername;
          db.collection('files').updateOne({filename: files[i].filename}, {$set: {access: files[i].access}});
        }
        if(files[i].owner == oldUsername)
        {
          files[i].owner = newUsername;
          db.collection('files').updateOne({filename: files[i].filename}, {$set: {owner: files[i].owner}});
        }
      }
    }
  });
}

router.post('/update', function(req, res, next) {
  var username = req.body.username;
  var password = encrypt(req.body.password);
  var password2 = req.body.password2;
  var password3 = req.body.password3;

  (async () => {
    return db.collection('users').countDocuments({username: username})
      .then(result => {
        if(result)
        {
          console.log('\n\nUsername Exists For ' + username + '\n\n');
          req.flash('info', 'Username Exists For ' + username);
          res.render('update', {messages: req.flash('info')});
        }
        else
        {
          db.collection('users').findOne({username: req.cookies.userData.username}, function(err, user) {
            if(user != null)
            {
              if(decrypt(user.password) == password3)
              {
                if (username != '' && decrypt(password) == '' && password2 == '' && password3 != '')
                {
                  if(username.length <= 18)
                  {
                    changeUsernameAccess(req.cookies.userData.username, username, req, res, next);
                    db.collection('users').updateOne({username: req.cookies.userData.username}, {$set: {username: username}});
                    res.clearCookie('userData');
                    res.location('/users/login');
                    res.redirect('/users/login');
                  }
                  else
                  {
                    console.log('\n\nThe username ' + username + ' is to long\n\n');
                    req.flash('info', 'The username ' + username + ' is to long');
                    res.render('update', {messages: req.flash('info')});
                  }
                }
                else if (username == '' && decrypt(password) != '' && password2 != '' && password3 != '')
                {
                  if (decrypt(password) == password2)
                  {
                    db.collection('users').updateOne({username: req.cookies.userData.username}, {$set: {password: password}});
                    res.clearCookie('userData');
                    res.location('/users/login');
                    res.redirect('/users/login');
                  }
                  else
                  {
                    req.flash('info', 'The new password and confirm new password field do not match');
                    res.render('update', {messages: req.flash('info')});
                  }

                }
                else if (username != '' && decrypt(password) != '' && password2 != '' && password3 != '')
                {
                  if (decrypt(password) == password2)
                  {
                    if(username.length <= 18)
                    {
                      changeUsernameAccess(req.cookies.userData.username, username, req, res, next);
                      db.collection('users').updateOne({username: req.cookies.userData.username}, {$set: {username: username, password: password}});
                      res.clearCookie('userData');
                      res.location('/users/login');
                      res.redirect('/users/login');
                    }
                    else
                    {
                      console.log('\n\nThe username ' + username + ' is to long\n\n');
                      req.flash('info', 'The username ' + username + ' is to long');
                      res.render('update', {messages: req.flash('info')});
                    }
                  }
                  else
                  {
                    req.flash('info', 'The new password and confirm new password field do not match');
                    res.render('update', {messages: req.flash('info')});
                  }
                }
                else
                {
                  req.flash('info', 'No update as there are no changes');
                  res.render('update', {messages: req.flash('info')});
                }
              }
              else
              {
                req.flash('info', 'The old password is wrong');
                res.render('update', {messages: req.flash('info')});
              }
            }
            else
            {
              res.location('/users/login');
              res.redirect('/users/login');
            }
          })
        }
    })
    .catch(err => console.error(`Failed to find document: ${err}`));})();
});



router.post('/login', function(req, res, next) {
  var username = req.body.username;
  var password = req.body.password;
  var found;
  (async () => {
    return db.collection('users').countDocuments({username: username})
      .then(result => {
        if(result)
        {
          db.collection('users').findOne({username: username}, function(err, user) {
            if(decrypt(user.password) == password)
            {
              if (req.cookies.userData != undefined)
              {
                res.clearCookie('userData');
              }
              res.cookie("userData", {username: username, password: user.password, loggedin: true, overwrite: true});
              console.log("\n\nLogin Success for " + username + '\n\n');
              res.location('/');
              res.redirect('/');
            }
            else
            {
              console.log("\n\nFailed to login as password or username is wrong\n\n");
              req.flash('info', "Failed to login as password or username is wrong");
              res.render('login', {messages: req.flash('info')});
            }
          })
        }
        else
        {
          console.log("\n\nFailed to login as password or username is wrong\n\n");
          req.flash('info', "Failed to login as password or username is wrong");
          res.render('login', {messages: req.flash('info')});
        }
        return result;
    })
    .catch(err => console.error(`Failed to find document: ${err}`));})();
});



router.post('/register', function(req, res, next) {
    var name = req.body.name;
    var username = req.body.username;
    var password = encrypt(req.body.password);
    var password2 = req.body.password2;
    var userAuth = req.body.userAuth;

    if(name != '' && username != '' && password != '' && password2 != '' && userAuth != '' && decrypt(password) == password2)
    {
      (async () => {
        return db.collection('users').countDocuments({username: username})
          .then(result => {
            if(result)
            {
              console.log('\n\nUsername Exists For ' + username + '\n\n');
              req.flash('info', 'Username Exists For ' + username);
              res.render('register', {messages: req.flash('info')});
            }
            else
            {
              if(username.length <= 18)
              {
                db.collection('users').findOne({username: 'Eric'}, function(err, user) {
                  if(decrypt(user.password) == userAuth)
                  {
                    db.collection('users').insert({name: name, username: username, password: password});
                    console.log('\n\nAccount Created For ' + username + '\n\n');
                    res.location('/users/login');
                    res.redirect('/users/login');
                  }
                  else
                  {
                    console.log('\n\nNot authorized to add an user account\n\n');
                    req.flash('info', 'Not Athorized To Add User Account');
                    res.render('register', {messages: req.flash('info')});
                  }
                });
              }
              else
              {
                console.log('\n\nThe username ' + username + ' is to long\n\n');
                req.flash('info', 'The username ' + username + ' is to long');
                res.render('register', {messages: req.flash('info')});
              }
            }
        })
        .catch(err => console.error(`Failed to find document: ${err}`));})();
    }
    else
    {
      console.log('Error: Blank Inputs Or Passwords Do Not Match');
      var errors = 0;
      if(name == '')
      {
        errors += 1;
      }
      if(username == '')
      {
        errors += 1;
      }
      if(decrypt(password) == '')
      {
        errors += 1;
      }
      if(password2 == '')
      {
        errors += 1;
      }
      if(decrypt(password) != password2)
      {
        errors += 1;
      }
      if(userAuth == '')
      {
        errors += 1;
      }


      if(name == '')
      {
        req.flash('info', 'Number of Errors: ' + errors + '  |  First Error: The name field is blank');
        res.render('register', {messages: req.flash('info')});
      }
      if(username == '')
      {
        req.flash('info', 'Number of Errors: ' + errors + '  |  First Error: The username field is blank');
        res.render('register', {messages: req.flash('info')});
      }
      if(decrypt(password) == '')
      {
        req.flash('info', 'Number of Errors: ' + errors + '  |  First Error: The password field is blank');
        res.render('register', {messages: req.flash('info')});
      }
      if(password2 == '')
      {
        req.flash('info', 'Number of Errors: ' + errors + '  |  First Error: The confirm password field is blank');
        res.render('register', {messages: req.flash('info')});
      }
      if(decrypt(password) != password2)
      {
        req.flash('info', 'Number of Errors: ' + errors + '  |  First Error: The password and confirm password field do not match');
        res.render('register', {messages: req.flash('info')});
      }
      if(userAuth == '')
      {
        req.flash('info', 'Number of Errors: ' + errors + '  |  First Error: The add user authorization field is blank');
        res.render('register', {messages: req.flash('info')});
      }
    }
});


router.get('/logout', function(req, res){
  res.clearCookie('userData');
  console.log('\n\nLogged Out\n\n');
  res.location('/users/login');
  res.redirect('/users/login');
});

module.exports = router;
