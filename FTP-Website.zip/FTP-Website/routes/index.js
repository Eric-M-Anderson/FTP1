var fs = require ("fs");
var express = require('express');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/FTP-Website');
var db = mongoose.connection;
var path = require('path');
var multer = require('multer');
var upload = multer({dest: './uploads'});
var router = express.Router();
const { exec } = require("child_process");
var nodeCmd = require('node-cmd');



/* GET home page. */
router.get('/', function(req, res, next) {
  try
  {
    if(req.cookies.userData.loggedin == true)
    {
      db.collection('users').findOne({username: req.cookies.userData.username}, function(err, user) {
        if(user.password == req.cookies.userData.password)
        {
          db.collection('files').find().toArray(function(err, result){
            if (err) throw err;
            if(result.length == 0)
            {
              res.render('index', {messages: req.cookies.userData.username});
            }
            else
            {
              res.render('index', {data: result, messages: req.cookies.userData.username});
            }
          });
        }
        else
        {
          req.flash('info', "You are not logged in and therefore cannot go to the server page");
          res.render('login', {messages: req.flash('info')});
          res.location('/users/login');
          res.redirect('/users/login');
        }
      });
    }
    else
    {
      req.flash('info', "You are not logged in and therefore cannot go to the server page");
      res.render('login', {messages: req.flash('info')});
      res.location('/users/login');
      res.redirect('/users/login');
    }
  }
  catch (e)
  {
    req.flash('info', "You are not logged in and therefore cannot go to the server page");
    res.render('login', {messages: req.flash('info')});
    res.location('/users/login');
    res.redirect('/users/login');
    console.log(e);
  }
});



router.get('/upload', function(req, res, next) {
  try
  {
    if(req.cookies.userData.loggedin == true)
    {
      db.collection('users').findOne({username: req.cookies.userData.username}, function(err, user) {
        if(user.password == req.cookies.userData.password)
        {
          res.render('upload');
        }
        else
        {
          req.flash('info', "You are not logged in and therefore cannot go to the server page");
          res.render('login', {messages: req.flash('info')});
          res.location('/users/login');
          res.redirect('/users/login');
        }
      });
    }
    else
    {
      req.flash('info', "You are not logged in and therefore cannot go to the server page");
      res.render('login', {messages: req.flash('info')});
      res.location('/users/login');
      res.redirect('/users/login');
    }
  }
  catch
  {
    req.flash('info', "You are not logged in and therefore cannot go to the server page");
    res.render('login', {messages: req.flash('info')});
    res.location('/users/login');
    res.redirect('/users/login');
  }
});



router.get('/download', function(req, res, next) {
  try
  {
    if(req.cookies.userData.loggedin == true)
    {
      db.collection('users').findOne({username: req.cookies.userData.username}, function(err, user) {
        if(user.password == req.cookies.userData.password)
        {
          res.render('download');
        }
        else
        {
          req.flash('info', "You are not logged in and therefore cannot go to the server page");
          res.render('login', {messages: req.flash('info')});
          res.location('/users/login');
          res.redirect('/users/login');
        }
      });
    }
    else
    {
      req.flash('info', "You are not logged in and therefore cannot go to the server page");
      res.render('login', {messages: req.flash('info')});
      res.location('/users/login');
      res.redirect('/users/login');
    }
  }
  catch
  {
    req.flash('info', "You are not logged in and therefore cannot go to the server page");
    res.render('login', {messages: req.flash('info')});
    res.location('/users/login');
    res.redirect('/users/login');
  }
});



router.get('/delete', function(req, res, next) {
  try
  {
    if(req.cookies.userData.loggedin == true)
    {
      db.collection('users').findOne({username: req.cookies.userData.username}, function(err, user) {
        if(user.password == req.cookies.userData.password)
        {
          res.render('delete');
        }
        else
        {
          req.flash('info', "You are not logged in and therefore cannot go to the server page");
          res.render('login', {messages: req.flash('info')});
          res.location('/users/login');
          res.redirect('/users/login');
        }
      });
    }
    else
    {
      req.flash('info', "You are not logged in and therefore cannot go to the server page");
      res.render('login', {messages: req.flash('info')});
      res.location('/users/login');
      res.redirect('/users/login');
    }
  }
  catch
  {
    req.flash('info', "You are not logged in and therefore cannot go to the server page");
    res.render('login', {messages: req.flash('info')});
    res.location('/users/login');
    res.redirect('/users/login');
  }
});



router.get('/access', function(req, res, next) {
  try
  {
    if(req.cookies.userData.loggedin == true)
    {
      db.collection('users').findOne({username: req.cookies.userData.username}, function(err, user) {
        if(user.password == req.cookies.userData.password)
        {
          db.collection('files').find().toArray(function(err, result){
            if (err) throw err;
            if(result.length == 0)
            {
              res.render('access', {messages: req.cookies.userData.username});
            }
            else
            {
              res.render('access', {data: result, messages: req.cookies.userData.username});
            }
          });
        }
        else
        {
          req.flash('info', "You are not logged in and therefore cannot go to the server page");
          res.render('login', {messages: req.flash('info')});
          res.location('/users/login');
          res.redirect('/users/login');
        }
      });
    }
    else
    {
      req.flash('info', "You are not logged in and therefore cannot go to the server page");
      res.render('login', {messages: req.flash('info')});
      res.location('/users/login');
      res.redirect('/users/login');
    }
  }
  catch
  {
    req.flash('info', "You are not logged in and therefore cannot go to the server page");
    res.render('login', {messages: req.flash('info')});
    res.location('/users/login');
    res.redirect('/users/login');
  }
});

router.get('/access/updateAccess', function(req, res, next) {
  res.location('/access');
  res.redirect('/access');
});



router.post('/upload', upload.single('FTPfiles'), function(req, res, next) {
  if(req.file)
  {
    console.log('Uploading File...');
    var file_access = req.body.restrict;
    var the_filename = req.file.originalname;
    var file = '/uploads/' + req.file.originalname;
    var filename = 'uploads/' + req.file.originalname;
    db.collection('files').findOne({filename: the_filename}, function(err, fileData) {
      if(fileData != null)
      {
        var upload = 'The file "' + the_filename + '" already exists on the server';

        try
        {
          console.log(req.file.filename);
          var delPathCMD = 'del "D:\\Data\\99._Websites\\FTP-Website\\uploads\\' + req.file.filename + '"';
          nodeCmd.get(delPathCMD, (err, data, stderr) => console.log(data));
        }
        catch (e)
        {
          console.log('File alreay on server');
          res.location('/');
        }

        db.collection('files').find().toArray(function(err, result){
          if (err) throw err;
          res.render('index', {data: result, messages: req.cookies.userData.username, upload: upload});
        });
        res.location('/');

      }
      else if (fileData == null)
      {
        fs.rename(req.file.path, './' + file, function (err){
          if (err) throw err;
        });

        var dataObj = new Date();
        var day = dataObj.getDate();
        var month = dataObj.getMonth() + 1;
        var year = dataObj.getFullYear();
        var hour = dataObj.getHours();
        var minutes = dataObj.getMinutes();
        var seconds = dataObj.getSeconds();

        var time = year + '-' + month + '-' + day + ' @ ' + hour + ':' + minutes + ':' + seconds;

        if(file_access == 'on')
        {
          db.collection('files').insert({filename: the_filename, uploadDate: time, owner: req.cookies.userData.username, access: [[req.cookies.userData.username, true]]});
        }
        else if (file_access == undefined)
        {
          db.collection('files').insert({filename: the_filename, uploadDate: time, owner: req.cookies.userData.username, access: []});
        }
        res.location('/upload');
        res.redirect('/upload');
      }
    });
  }
  else
  {
    console.log('No File Uploading');
    res.location('/');
  }
});



router.post('/download', function(req, res, next) {
  var filename = req.body.filename;
  var file = `D:/Data/99._Websites/FTP-Website/uploads/` + filename;
  var upload = '"' + filename + '" does not exist on the FTP server';
  var found = false;
  db.collection('files').find().toArray(function(err, data){
    if (err) throw err;
    db.collection('files').find({filename: filename}).toArray(function(err, result){
      if (err) throw err;
      if(result.length == 0)
      {
        if(data.length == 0)
        {
          res.render('index', {messages: req.cookies.userData.username, upload: upload});
        }
        else
        {
          res.render('index', {data: data, messages: req.cookies.userData.username, upload: upload});
        }
      }
      else
      {
        db.collection('files').findOne({filename: filename}, function(err, fileData) {
          array_access = fileData.access;
          if(fileData.access.length != 0)
          {
            var i;
            for (i = 0; i < array_access.length; i++) {
              if(array_access[i][0] == req.cookies.userData.username)
              {
                found = true;
                break;
              }
            }
            if(found == true)
            {
              res.download(file);
              //res.location('/download');
              //res.redirect('/download');
            }
            else
            {
              upload = 'You do not have permission to download the file "' + filename + '". Talk to the file owner to change the permissions.';
              res.render('index', {data: data, messages: req.cookies.userData.username, upload: upload});
            }
          }
          else
          {
            res.download(file);
            //res.location('/download');
            //res.redirect('/download');
          }
        });
      }
    });
  });
});



router.post('/delete', function(req, res, next) {
  var filename = req.body.filename;
  var file = `D:/Data/99._Websites/FTP-Website/uploads/` + filename;
  var upload = '"' + filename + '" does not exist on the FTP server';
  var found = false;
  var delPathCMD;
  db.collection('files').find().toArray(function(err, data){
    if (err) throw err;
    db.collection('files').find({filename: filename}).toArray(function(err, result){
      if (err) throw err;
      if(result.length == 0)
      {
        if(data.length == 0)
        {
          res.render('index', {messages: req.cookies.userData.username, upload: upload});
        }
        else
        {
          res.render('index', {data: data, messages: req.cookies.userData.username, upload: upload});
        }
      }
      else
      {
        db.collection('files').findOne({filename: filename}, function(err, fileData) {
          array_access = fileData.access;
          if(fileData.access.length != 0)
          {
            var i;
            console.log(delPathCMD);
            for (i = 0; i < array_access.length; i++) {
              if(array_access[i][0] == req.cookies.userData.username && array_access[i][1] == true)
              {
                found = true;
                break;
              }
            }
            if(found == true)
            {
              try
              {
                db.collection('files').deleteOne({ filename: filename });
                delPathCMD = 'del "D:\\Data\\99._Websites\\FTP-Website\\uploads\\' + filename + '"';
                nodeCmd.get(delPathCMD, (err, data, stderr) => console.log(data));
                res.location('/delete');
                res.redirect('/delete');
              }
              catch (e)
              {
                console.log(e);
                res.location('/');
                res.redirect('/');
              }
            }
            else
            {
              upload = 'You do not have permission to delete the file "' + filename + '". Talk to the file owner to change the permissions.';
              res.render('index', {data: data, messages: req.cookies.userData.username, upload: upload});
              //res.location('/');
            }
          }
          else
          {
            try
            {
              db.collection('files').deleteOne({ filename: filename });
              delPathCMD = 'del "D:\\Data\\99._Websites\\FTP-Website\\uploads\\' + filename + '"';
              nodeCmd.get(delPathCMD, (err, data, stderr) => console.log(data));
              res.location('/delete');
              res.redirect('/delete');
            }
            catch (e)
            {
              console.log(e);
              res.location('/');
              res.redirect('/');
            }
          }
        });
      }
    });
  });
});



var currentFilename = '';

router.post('/access', function(req, res, next) {
  var filename = req.body.accessFile;
  var userList = [];
  var usernamesUsed = [];
  currentFilename = filename;
  db.collection('files').findOne({filename: filename}, function(err, fileData) {
    db.collection('users').find().toArray(function(err, result){
      if (err) throw err;
      if(fileData != null)
      {
        var i;
        for (i = 0; i < fileData.access.length; i++)
        {
          userList.push(fileData.access[i]);
          usernamesUsed.push(fileData.access[i][0]);
        }

        var j;
        for (j = 0; j < result.length; j++)
        {
          if(usernamesUsed.includes(result[j].username))
          {
            console.log('skipped');
          }
          else
          {
            userList.push([result[j].username, undefined]);
          }
        }

        res.render('userstoadd', {dataF: fileData, data: result, file: filename, writer: req.cookies.userData.username, userAccessList: userList });
      }
      else
      {
        db.collection('files').find().toArray(function(err, result){
          if (err) throw err;
          var upload = 'The file "' + filename + '" does not exist';
          if(result.length == 0)
          {
            res.render('access', {messages: req.cookies.userData.username, upload: upload});
          }
          else
          {
            res.render('access', {data: result, messages: req.cookies.userData.username, upload: upload});
          }
        });
      }
    });
  });
});



router.post('/access/updateAccess', function(req, res, next) {
  var accessArray = [];
  var unrestrict = req.body.unrestrict;
  if(unrestrict == 'on')
  {
    db.collection('files').updateOne({filename: currentFilename}, {$set: {access: accessArray}});
  }
  else if(req.body.read == undefined && req.body.delete == undefined)
  {
    accessArray.push([req.cookies.userData.username, true]);
    db.collection('files').updateOne({filename: currentFilename}, {$set: {access: accessArray}});
  }
  else
  {
    var read = req.body.read;
    var canDelete = req.body.delete;
    var canDeleteArray = [];
    var filename = currentFilename;
    var oneUserArray = [];

    accessArray.push([req.cookies.userData.username, true]);

    try
    {
      if (typeof canDelete == 'object')
      {
        var i;
        for (i = 0; i < canDelete.length; i++)
        {
          canDeleteArray.push(canDelete[i]);
          accessArray.push([canDelete[i], true]);
        }
      }
      else if(typeof canDelete == 'string')
      {
        canDeleteArray.push(canDelete);
        accessArray.push([canDelete, true]);
      }
    }
    catch (e)
    {
      console.log(e);
    }

    try
    {
      if (typeof read == 'object')
      {
        var j;
        var z;
        for (j = 0; j < read.length; j++)
        {
          if(canDeleteArray.length > 0)
          {
            for (z = 0; z < canDeleteArray.length; z++)
            {
              if(canDeleteArray.includes(read[j]))
              {
                console.log('');
              }
              else
              {
                accessArray.push([read[j], false]);
              }
            }
          }
          else
          {
            accessArray.push([read[j], false]);
          }
        }
      }
      else if(typeof read == 'string')
      {
        if(canDeleteArray.includes(read))
        {
          console.log('');
        }
        else
        {
          accessArray.push([read, false]);
        }
      }
    }
    catch (e)
    {
      console.log(e);
    }
    db.collection('files').updateOne({filename: filename}, {$set: {access: accessArray}});
  }

  res.location('/access');
  res.redirect('/access');
});

module.exports = router;
